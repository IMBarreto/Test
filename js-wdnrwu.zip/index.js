// A. Questionary

// 1
var a = 'foo';
var b = a;
b = 'bar'
console.log(a); // What will be the output?

////////

// 2
var obj1 = {
    a: 'foo'
};
var obj2 = obj1;
obj2.a = 'bar';

console.log(obj1); // What will it output?

////////
// 3
console.log({} ? true : false); // What will output this expression? // empty object

////////
// 4
console.log([] ? true : false); // What will output this expression? // empty array



// B. Hands-on test
// * jquery library is optional (not required)
// * Can search documentation in the internet

import './style.css'
import { sum } from './sum'

function init () {
  // 1. Inside this function:
  // 1.1. Create 100 <divs> inside the container which is in the HTML
  // 1.2. Each div must have a <span> with a text that identifies it.
  //      Use the index as a suffix eg. element-1, element-2, element-3, ...

  

  // 2. Use CSS in style.css to do the following:
  // 2.1 Make the container scrolls the content
  // 2.2. Make the divs be visible including borders (specially right border)



}

init()

// 3. Write below a basic unit-test for the `sum` function that was already imported above









// C. Further technical questions

// 1. Unit Test: Do you know about TDD (Test driven development), BDD (Behaviour driven development) methodologies?
// 2. Styles: How comfortable are you with "responsive web development"?



